#define FPRINTFTIME 1
#include "nstrftime.c"
