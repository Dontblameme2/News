#include <config.h>
#define SE_LABEL_INLINE _GL_EXTERN_INLINE
#include <selinux/label.h>
